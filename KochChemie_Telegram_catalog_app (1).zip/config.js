// Имя бота без @
window.KC_BOT = 'vikron_koch_bot';
// true — когда запущена программа бота (bot.py): заявки идут в группу «Заявки Koch-Chemie».
// false — бот не запущен: кнопка «Заказать» показывает телефон и чат менеджера.
window.KC_BOT_LIVE = false;
// @username менеджера в Telegram (необязательно), например 'vikron_manager'
window.KC_MANAGER = '';
